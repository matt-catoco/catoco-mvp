# Cataco logo concepts — full set

All five directions explored during logo selection, each as a standalone
512×512 SVG in both light (teal bg) and dark (ink bg) variants — same
construction convention as the shipped production mark (rounded square,
`rx=113`, dashed = open/in motion, solid = locked/decided).

| File | Concept | Status |
|---|---|---|
| `cataco-concept-01-convergence-dot` | Convergence Dot — six open votes radiate into one solid decision | Alternate |
| `cataco-concept-02-converging-paths` | Converging Paths — three journeys climbing to one point | Alternate |
| `cataco-concept-03-element-tile` | Element Tile — dashed square holding a locked diamond | **Shipped mark** (production files live in `cataco-logo-final/`) |
| `cataco-concept-04-three-way-venn` | Three-Way Venn — three overlapping circles, one center | Alternate |
| `cataco-concept-05-vote-cluster` | Vote Cluster — scattered open options, one clear winner | Alternate |

Each SVG is self-contained (no external font/asset dependencies) and safe to
drop into any infographic, deck, or design tool at any size.
